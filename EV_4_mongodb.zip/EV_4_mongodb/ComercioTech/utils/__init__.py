"""Paquete de utilidades — ComercioTech."""
