# Proyecto ComercioTech - MongoDB Atlas

Este proyecto es la implementación en Python del backend para ComercioTech utilizando MongoDB Atlas.

## Requisitos Previos
- Python 3.8+

## Instalación
1. Clonar este repositorio.
2. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```
3. Configurar conexión a Atlas:
   - Copia el archivo `.env.example` a `.env`
   - Edita el archivo `.env` y reemplaza la variable `MONGO_URI` con el Connection String SRV de tu clúster de MongoDB Atlas.

## Estructura
- `main.py`: Punto de entrada.
- `menu.py`: Interfaz de consola.
- `login.py`: Autenticación con bcrypt.
- `config/`: Conexión segura a Atlas.
- `models/`: Clases de datos.
- `crud/`: Operaciones CRUD.
- `services/`: Pipelines de agregación (Fase 4).
- `utils/`: Validaciones estandarizadas.

## Ejecución
```bash
python main.py
```
