"""
config/conexion.py — Módulo de conexión segura a MongoDB
=========================================================

JUSTIFICACIÓN DE PYTHON + PYMONGO COMO STACK DE DESARROLLO (G.21)
------------------------------------------------------------------

1. COMPATIBILIDAD:
   PyMongo es el driver oficial y recomendado por MongoDB Inc. para Python.
   Soporta todas las funcionalidades de MongoDB 8.x: transacciones ACID
   multi-documento, agregaciones, Change Streams, GridFS y operaciones bulk.
   Compatible con Python 3.8+ en Windows, Linux y macOS sin dependencias nativas.

2. RENDIMIENTO:
   PyMongo 4.x utiliza C-Extensions (BSON en C) para serialización/
   deserialización de documentos, logrando rendimientos similares a drivers
   de lenguajes compilados. El pool de conexiones reutiliza sockets TCP,
   eliminando el overhead de establecer una nueva conexión por cada operación.

3. SEGURIDAD:
   - La URI de conexión se carga desde variables de entorno (.env),
     nunca hardcodeada en el código fuente.
   - serverSelectionTimeoutMS evita bloqueos si MongoDB no responde.
   - Las contraseñas de operadores se almacenan como hashes bcrypt,
     nunca en texto plano.

4. MANTENIBILIDAD:
   - Patrón Singleton: una sola instancia de MongoClient compartida
     en toda la aplicación, evitando múltiples pools de conexiones.
   - Type hints en todas las funciones para compatibilidad con linters.
   - Docstrings detallados en cada función, base para la Fase 4.

Referencia normativa: Sección 4.1.6 · Puntos G.21, G.22
"""

import os
import time
import logging
from typing import Optional

from pymongo import MongoClient
from pymongo.database import Database
from pymongo.errors import (
    ConnectionFailure,
    ServerSelectionTimeoutError,
    ConfigurationError,
    OperationFailure,
)
from dotenv import load_dotenv

# ─── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# ─── Cargar .env ─────────────────────────────────────────────────────────────
# Busca el archivo .env en el directorio raíz del proyecto
_ENV_PATH = os.path.join(os.path.dirname(__file__), "..", ".env")
load_dotenv(dotenv_path=_ENV_PATH)

# ─── Singleton ───────────────────────────────────────────────────────────────
_client: Optional[MongoClient] = None


def get_client(max_reintentos: int = 3, espera_seg: float = 2.0) -> MongoClient:
    """Retorna el cliente MongoDB singleton con pool de conexiones.

    Lee la URI desde la variable de entorno MONGO_URI definida en .env.
    Por defecto usa ``mongodb://localhost:27017/`` si la variable no existe.

    Implementa reintentos automáticos con espera incremental cuando el
    servidor no responde (útil al arrancar la app antes de que MongoDB esté listo).

    Args:
        max_reintentos: Número máximo de intentos de conexión (default: 3).
        espera_seg:     Segundos de espera base entre reintentos (default: 2.0).

    Returns:
        MongoClient: Instancia singleton del cliente MongoDB.

    Raises:
        ConnectionFailure: Si no se puede conectar tras todos los reintentos.
        OperationFailure:  Si las credenciales en la URI son incorrectas.
    """
    global _client

    if _client is not None:
        return _client

    # Leer URI desde .env; si no existe usa localhost sin autenticación
    uri = os.getenv("MONGO_URI", "mongodb://localhost:27017/")

    max_pool = int(os.getenv("MONGO_MAX_POOL_SIZE", "10"))
    min_pool = int(os.getenv("MONGO_MIN_POOL_SIZE", "2"))
    connect_timeout = int(os.getenv("MONGO_CONNECT_TIMEOUT_MS", "3000"))
    server_timeout  = int(os.getenv("MONGO_SERVER_SELECTION_TIMEOUT_MS", "5000"))

    for intento in range(1, max_reintentos + 1):
        try:
            logger.info(
                "Conectando a MongoDB (intento %d/%d): %s",
                intento, max_reintentos,
                uri.split("@")[-1],     # Ocultar credenciales en el log
            )
            cliente = MongoClient(
                uri,
                maxPoolSize=max_pool,
                minPoolSize=min_pool,
                connectTimeoutMS=connect_timeout,
                serverSelectionTimeoutMS=server_timeout,
            )
            # Verificar conectividad real (el MongoClient es lazy)
            cliente.admin.command("ping")
            _client = cliente
            logger.info("✅ Conexión a MongoDB establecida correctamente.")
            return _client

        except ServerSelectionTimeoutError:
            logger.warning(
                "MongoDB no responde (intento %d/%d). Reintentando en %.0fs...",
                intento, max_reintentos, espera_seg * intento,
            )
            if intento < max_reintentos:
                time.sleep(espera_seg * intento)

        except OperationFailure as e:
            # Error de autenticación: no tiene sentido reintentar
            logger.error("❌ Error de autenticación: %s", e)
            raise

    raise ConnectionFailure(
        f"No se pudo conectar a MongoDB después de {max_reintentos} intentos.\n"
        "  · Verificar que el servicio MongoDB está corriendo.\n"
        "  · Revisar MONGO_URI en el archivo .env.\n"
        "  · URI actual (sin credenciales): "
        f"{os.getenv('MONGO_URI', 'mongodb://localhost:27017/').split('@')[-1]}"
    )


def get_db() -> Database:
    """Retorna la base de datos especificada en MONGO_DB (default: comerciotech).

    Returns:
        Database: Objeto de base de datos listo para operar colecciones.
    """
    db_name = os.getenv("MONGO_DB", "comerciotech")
    return get_client()[db_name]


def cerrar_conexion() -> None:
    """Cierra el cliente MongoDB y libera el pool de conexiones.

    Llamar siempre al finalizar la aplicación para evitar conexiones huérfanas.
    """
    global _client
    if _client is not None:
        _client.close()
        _client = None
        logger.info("Conexión a MongoDB cerrada.")
