"""Paquete de configuración — ComercioTech."""
